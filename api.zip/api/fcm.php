<?php

date_default_timezone_set('Asia/Bangkok');
include '../db.php'; // Hubungkan ke file koneksi database

// Menyimpan data request untuk debugging
file_put_contents('request.txt', print_r($_REQUEST, true));

// Data yang akan diupdate
$santri_id = $_GET['userId']; // ID santri yang bersangkutan
$fcm_token = $_GET['token']; // Token FCM yang akan diperbarui

if (!$santri_id || !$fcm_token) {
    echo json_encode(['status' => 'error', 'message' => 'ID atau token tidak ditemukan']);
    exit();
}

// Cek apakah ID santri ada dalam tabel santri
$sql_check_santri = "SELECT * FROM `santri` WHERE `id` = '$santri_id'";
$result_check_santri = mysqli_query($conn, $sql_check_santri);

if (mysqli_num_rows($result_check_santri) == 0) {
    // Jika ID santri tidak ditemukan, kembalikan pesan error
    echo json_encode(['status' => 'error', 'message' => 'ID santri tidak ditemukan']);
    exit();
}

// Update token FCM untuk santri ini
$update_query = "UPDATE `santri` SET `fcm` = '$fcm_token' WHERE `id` = '$santri_id'";

if (mysqli_query($conn, $update_query)) {
    echo json_encode(['status' => 'success', 'message' => 'Token FCM berhasil diperbarui']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal memperbarui token FCM']);
}

mysqli_close($conn); // Tutup koneksi database
?>
