<?php
header("Content-Type: application/json");

include '../db.php'; // Sesuaikan dengan file koneksi database Anda

function getDataByPassword($table, $password) {
    global $conn;
    
    // Prepare the SQL statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM $table WHERE password LIKE ?");
    $stmt->bind_param("s", $password);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        return array("status" => "success", "data" => $data);
    } else {
        return array("status" => "error", "message" => "No records found");
    }

    $stmt->close();
}

// Check if the password and table parameters are provided
if (isset($_GET['password']) && isset($_GET['table'])) {
    $password = $_GET['password'];
    $table = $_GET['table'];

    switch ($table) {
        case 'santri':
        case 'petugas':
            $response = getDataByPassword($table, $password);
            echo json_encode($response);
            break;
        default:
            echo json_encode(array("status" => "error", "message" => "Invalid table name"));
            break;
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Missing parameters"));
}

$conn->close();
