<?php
include '../db.php';

$id = $_GET['id'];

$sql = "SELECT * FROM daftar_tagihan WHERE santri_id = $id ORDER BY `daftar_tagihan`.`id` DESC";
$result = $conn->query($sql);

$data = array();

// Check if there are results and fetch data
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $data[] = $row;
  }
}

$sql = "SELECT * FROM `santri` WHERE `id` = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $jsonData = '
{
  "data_santri": {
    "id": "' . $row['id'] . '",
    "nama": "' . $row['nama_santri'] . '",
    "asrama": "' . $row['asrama'] . '",
    "no_hp": "' . $row['no_hp'] . '",
    "wali_santri": "' . $row['nama_walisantri'] . '"
  },
  "daftar_tagihan": ' . json_encode($data) . '
}';
  echo $jsonData;
} else {
  echo json_encode(['message' => 'Santri tidak ditemukan']);
  exit();
}
