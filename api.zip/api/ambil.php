<?php

date_default_timezone_set('Asia/Bangkok');
include '../db.php'; // Hubungkan ke file koneksi database

// Data yang akan diinsert atau diupdate
$hari = date('l'); // Hari ini (nama hari dalam bahasa Inggris)
$tanggal = date('Y-m-d'); // Tanggal hari ini
$jam_sekarang = date('H:i:s'); // Waktu saat ini (sekarang)
$santri_id = $_GET['id']; // ID santri yang bersangkutan

if (!$santri_id) {
    echo json_encode(['status' => 'error', 'message' => 'ID tidak ditemukan']);
    exit();
}

// Cek apakah ID santri ada dalam tabel santri
$sql_check_santri = "SELECT * FROM `santri` WHERE `id` = '$santri_id'";
$result_check_santri = mysqli_query($conn, $sql_check_santri);

if (mysqli_num_rows($result_check_santri) == 0) {
    // Jika ID santri tidak ditemukan, kembalikan pesan error
    echo json_encode(['status' => 'error', 'message' => 'ID santri tidak ditemukan']);
    exit();
}

// Daftar nama hari dalam bahasa Indonesia
$nama_hari = [
    'Sunday' => 'Minggu',
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu'
];

// Mengubah nama hari ke dalam bahasa Indonesia
$hari_indonesia = $nama_hari[$hari] ?? $hari; // Jika tidak ada, gunakan nama hari dalam bahasa Inggris

// Cek apakah data dengan tanggal hari ini sudah ada untuk santri ini
$sql_check = "SELECT * FROM `history_pengambilan` WHERE `tanggal` = '$tanggal' AND `santri_id` = '$santri_id'";
$result_check = mysqli_query($conn, $sql_check);

if (mysqli_num_rows($result_check) > 0) {
    $row = mysqli_fetch_assoc($result_check);

    // Cek apakah kolom jam_1 dan jam_2 sudah terisi
    if ($row['jam_1'] && $row['jam_2']) {
        echo json_encode(['status' => 'error', 'message' => 'Kupon tidak bisa diambil lagi hari ini']);
    } elseif ($row['jam_1'] && !$row['jam_2']) {
        // Jika jam_1 terisi dan jam_2 belum terisi, lakukan UPDATE dengan jam_2
        $update_query = "UPDATE `history_pengambilan` SET `jam_2` = '$jam_sekarang' WHERE `tanggal` = '$tanggal' AND `santri_id` = '$santri_id'";

        if (mysqli_query($conn, $update_query)) {
            echo json_encode(['status' => 'success', 'message' => 'Kupon sudah diambil 2x']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Data tidak dapat diupdate']);
        }
    }
} else {
    // Jika data belum ada, lakukan INSERT dengan jam_1
    $insert_query = "INSERT INTO `history_pengambilan` (`id`, `hari`, `tanggal`, `jam_1`, `jam_2`, `santri_id`)
                     VALUES (NULL, '$hari_indonesia', '$tanggal', '$jam_sekarang', NULL, '$santri_id')";

    if (mysqli_query($conn, $insert_query)) {
        echo json_encode(['status' => 'success', 'message' => 'Kupon sudah diambil 1x']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak dapat ditambahkan']);
    }
}

mysqli_close($conn); // Tutup koneksi database
