<?php
header('Content-Type: application/json; charset=utf-8');
include '../db.php'; // Sesuaikan dengan file koneksi database Anda

// Ambil santri_id dari parameter GET (asumsikan di-request dari URL)
$santri_id = $_GET['id'];

// Query untuk mengambil data notifikasi_pembayaran berdasarkan santri_id
$sql = "SELECT * FROM notifikasi_pembayaran WHERE santri_id = $santri_id";
$result = mysqli_query($conn, $sql);

$data_json = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data_json['notifikasi_pembayaran'][] = [
        "id" => $row['id'],
        "jenis_kupon" => $row['jenis_kupon'],
        "tanggal_pembayaran" => $row['tanggal_pembayaran'],
        "santri_id" => $row['santri_id']
    ];
}

// Menampilkan data JSON
echo json_encode($data_json, JSON_PRETTY_PRINT);

// Menutup koneksi database
mysqli_close($conn);
