<?php
header('Content-Type: application/json; charset=utf-8');

include '../db.php';

// Total kupon awal
$total_kupon = 60;

// Query untuk mengambil data history_pengambilan berdasarkan santri_id
$santri_id = $_GET['id'];
$bulanSekarang = date('m');
$sql = "SELECT * FROM `history_pengambilan` WHERE MONTH(`tanggal`) = $bulanSekarang AND `santri_id` = $santri_id";
$result = mysqli_query($conn, $sql);

$history_pengambilan = [];
$total_pengambilan = 0;

while ($row = mysqli_fetch_assoc($result)) {
  // Menyiapkan nilai jam_1 dan jam_2
  $jam_1 = !empty($row['jam_1']) ? $row['jam_1'] : "belum diambil";
  $jam_2 = (!empty($row['jam_2']) && $row['jam_2'] !== '-') ? $row['jam_2'] : "belum diambil";

  $history_pengambilan[] = [
    "id" => $row['id'],
    "hari" => $row['hari'],
    "tanggal" => $row['tanggal'],
    "jam_1" => $jam_1,
    "jam_2" => $jam_2,
    "santri_id" => $row['santri_id']
  ];

  // Menghitung kupon yang diambil berdasarkan jam_1 dan jam_2
  if ($jam_1 !== "belum diambil") {
    $total_pengambilan++;
  }
  if ($jam_2 !== "belum diambil") {
    $total_pengambilan++;
  }
}

// Mengurangi jumlah total kupon dengan jumlah pengambilan
$sisa_kupon = $total_kupon - $total_pengambilan;

// Menyiapkan data JSON akhir
$data_json = [
  "total_kupon" => $sisa_kupon,
  "history_pengambilan" => $history_pengambilan
];

// Menampilkan data JSON
echo json_encode($data_json, JSON_PRETTY_PRINT);

mysqli_close($conn);
