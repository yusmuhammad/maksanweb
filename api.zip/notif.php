<?php
include 'db.php';

header('Content-Type: application/json');

$response = [];

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $response['status'] = 'error';
    $response['message'] = 'ID santri tidak valid.';
    echo json_encode($response);
    exit();
}

$id = $_GET['id'];

// Menyiapkan query untuk mengambil data santri
$sql = "SELECT * FROM `santri` WHERE `id` = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    $response['status'] = 'error';
    $response['message'] = 'Gagal mempersiapkan statement: ' . $conn->error;
    echo json_encode($response);
    exit();
}

// Mengikat parameter ke statement
$stmt->bind_param("i", $id);

// Menjalankan statement
$stmt->execute();

// Mendapatkan hasil
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    $response['status'] = 'error';
    $response['message'] = 'Santri tidak ditemukan.';
    echo json_encode($response);
    exit();
}

// Mendapatkan data santri
$nama_santri = $row['nama_santri'];
$fcm = $row['fcm'];
// Mengambil tanggal saat ini dalam format yang diinginkan
$tanggal_sekarang = date('Y-m-d');

// Cek apakah ada tagihan yang belum lunas untuk tanggal saat ini
$cek_tagihan_sql = "SELECT * FROM `daftar_tagihan` WHERE `santri_id` = ? AND `tanggal` = ? AND `status` = 'belum lunas'";
$cek_tagihan_stmt = $conn->prepare($cek_tagihan_sql);

if ($cek_tagihan_stmt === false) {
    $response['status'] = 'error';
    $response['message'] = 'Gagal mempersiapkan statement: ' . $conn->error;
    echo json_encode($response);
    exit();
}

$cek_tagihan_stmt->bind_param("is", $id, $tanggal_sekarang);
$cek_tagihan_stmt->execute();
$cek_tagihan_result = $cek_tagihan_stmt->get_result();

if ($cek_tagihan_result->num_rows > 0) {
    $response['status'] = 'warning';
    $response['message'] = 'Tagihan untuk tanggal ini sudah ada dan belum lunas. Menyisipkan notifikasi saja.';
} else {
    // Jika tidak ada tagihan yang belum lunas, sisipkan tagihan baru dan notifikasi
    $nama_bulan = array(
        1 => 'Januari',
        2 => 'Februari',
        3 => 'Maret',
        4 => 'April',
        5 => 'Mei',
        6 => 'Juni',
        7 => 'Juli',
        8 => 'Agustus',
        9 => 'September',
        10 => 'Oktober',
        11 => 'November',
        12 => 'Desember'
    );

    $bulan_angka = date('n'); // Mengambil angka bulan saat ini
    $bulan = $nama_bulan[$bulan_angka]; // Mendapatkan nama bulan
    $jumlah = 300000;
    $status = 'belum lunas';
    $resi = 'ABCD1234';
    $santri_id = $id; // Menggunakan ID santri yang telah diambil

    // Query SQL untuk menyisipkan data ke daftar_tagihan
    $insert_tagihan_sql = "INSERT INTO `daftar_tagihan` (`bulan`, `tanggal`, `jumlah`, `status`, `resi`, `santri_id`) VALUES (?, ?, ?, ?, ?, ?)";
    $insert_tagihan_stmt = $conn->prepare($insert_tagihan_sql);

    if ($insert_tagihan_stmt === false) {
        $response['status'] = 'error';
        $response['message'] = 'Gagal mempersiapkan statement: ' . $conn->error;
        echo json_encode($response);
        exit();
    }

    $insert_tagihan_stmt->bind_param("ssisss", $bulan, $tanggal_sekarang, $jumlah, $status, $resi, $santri_id);

    if ($insert_tagihan_stmt->execute()) {
        $response['status'] = 'success';
        $response['message'] = 'Data tagihan berhasil disisipkan dengan ID: ' . $insert_tagihan_stmt->insert_id;
        $token = $fcm;
                $title = 'Tagihan';
                $body = 'Kupon Makan Untuk Santri '.$nama_santri;
                sendNotificationRequest($token, $title, $body);
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Gagal menyisipkan data tagihan: ' . $insert_tagihan_stmt->error;
        echo json_encode($response);
        exit();
    }

    $insert_tagihan_stmt->close();
}

// Mengambil tanggal saat ini dalam format yang diinginkan
$tanggal_pembayaran = date('Y-m-d');

// Query SQL untuk menyisipkan data notifikasi pembayaran
$notifikasi_sql = "INSERT INTO `notifikasi_pembayaran` (`id`, `jenis_kupon`, `tanggal_pembayaran`, `santri_id`) VALUES (NULL, 'makan', ?, ?)";
$notifikasi_stmt = $conn->prepare($notifikasi_sql);

if ($notifikasi_stmt === false) {
    $response['status'] = 'error';
    $response['message'] = 'Gagal mempersiapkan statement notifikasi: ' . $conn->error;
    echo json_encode($response);
    exit();
}

// Mengikat parameter ke statement untuk notifikasi
$notifikasi_stmt->bind_param("si", $tanggal_pembayaran, $id);

// Menjalankan statement untuk notifikasi
if ($notifikasi_stmt->execute()) {
    $response['status'] = 'success';
    $response['message'] = 'Data notifikasi berhasil disisipkan dengan ID: ' . $notifikasi_stmt->insert_id;
      $token = $fcm;
                $title = 'Tagihan';
                $body = 'Kupon Makan Untuk '.$nama_santri;
                sendNotificationRequest($token, $title, $body);
} else {
    $response['status'] = 'error';
    $response['message'] = 'Gagal menyisipkan data notifikasi: ' . $notifikasi_stmt->error;
}

// Menutup statement untuk notifikasi
$notifikasi_stmt->close();
$cek_tagihan_stmt->close();

// Menutup koneksi
$conn->close();

echo json_encode($response);


function sendNotificationRequest($token, $title, $body) {
    // Initialize cURL session
    $ch = curl_init();

    // Hardcoded service account URL
    $serviceAccountUrl = 'https://yusril.sikapngalah.com/api/serviceAccountKey.json';

    // Prepare the URL with query parameters
    $url = sprintf(
        'http://147.139.201.32:37000/sendNotification?token=%s&title=%s&body=%s&serviceAccountUrl=%s',
        urlencode($token),
        urlencode($title),
        urlencode($body),
        urlencode($serviceAccountUrl)
    );

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

    // Set HTTP headers
    $headers = array();
    $headers[] = 'Accept: */*';
    $headers[] = 'User-Agent: Thunder Client (https://www.thunderclient.com)';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Execute the cURL request
    $result = curl_exec($ch);

    // Check for cURL errors
    if (curl_errno($ch)) {
        $error = 'Error:' . curl_error($ch);
        curl_close($ch);
        return $error;
    }

    // Close cURL session
    curl_close($ch);

    // Return the result
    return $result;
}
?>
