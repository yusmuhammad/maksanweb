<?php
include 'db.php';

$id = $_GET['id'];
$sql = "SELECT * FROM `santri` WHERE `id` = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $url = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" . $row["id"];
    $content = file_get_contents($url);
} else {
    echo "Santri tidak ditemukan";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Tanda Penduduk Santri</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .card {
            max-width: 650px;
        }

        .card img {
            width: 200px;
            height: 200px;
            float: left;
            margin-right: 50px;
            padding: 10px;
            outline: 2px solid black;
            box-sizing: border-box;
        }
    </style>
</head>

<body>
    <div class="container">
        <br>
        <div class="card">
            <h2 class="text-center">Kartu Tanda Santri</h2>
            <div class="card-body">
                <img src="data:image/png;base64,<?= base64_encode($content) ?>" alt="Kartu Tanda Santri" />
                <h5 class="card-title">Nama: <?php echo htmlspecialchars($row["nama_santri"]); ?></h5>
                <p class="card-text">Asrama: <?php echo htmlspecialchars($row["asrama"]); ?></p>
                <p class="card-text">No. HP: <?php echo htmlspecialchars($row["no_hp"]); ?></p>
                <p class="card-text">Nama Walisantri: <?php echo htmlspecialchars($row["nama_walisantri"]); ?></p>
            </div>
        </div>
        <br>
        <br>
        <br>
        Password Wali santri : <?php echo htmlspecialchars($row["password"]); ?>
    </div>

</body>

</html>