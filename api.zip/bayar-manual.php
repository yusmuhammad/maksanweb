<?php
header("Content-Type: application/json");

include 'db.php'; // Sesuaikan dengan file koneksi database Anda

function updateStatus($id) {
    global $conn;

    $status = "Lunas"; // Status yang diubah menjadi "Lunas"

    // Prepare the SQL statement to prevent SQL injection
    $stmt = $conn->prepare("UPDATE daftar_tagihan SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);

    if ($stmt->execute()) {
        return array("status" => "success", "message" => "Record updated successfully");
    } else {
        return array("status" => "error", "message" => "Failed to update record");
    }

    $stmt->close();
}

// Check if the id parameter is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $response = updateStatus($id);
    echo json_encode($response);
} else {
    echo json_encode(array("status" => "error", "message" => "Missing parameters"));
}

$conn->close();
?>
