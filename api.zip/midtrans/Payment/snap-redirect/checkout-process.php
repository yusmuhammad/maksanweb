<?php
require '../../../db.php';

$data_id = $_GET['santri_id'];
$tagihan_id = $_GET['tagihan_id'];

// Generate random string for 'resi' field
$resi = bin2hex(random_bytes(5)); // 10 bytes of random data, resulting in a 20-character hex string

// SQL query to fetch data
$select_sql = "
    SELECT 
        dt.*, 
        s.*
    FROM 
        daftar_tagihan dt
    JOIN 
        santri s 
    ON 
        dt.santri_id = s.id
    WHERE 
        dt.id = ? 
    AND 
        dt.santri_id = ?;
";

$stmt = $conn->prepare($select_sql);
$stmt->bind_param('ii', $tagihan_id, $data_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if ($data) {
    $tagihan = array(
        'id' => $data['id'],
        'bulan' => $data['bulan'],
        'jumlah' => $data['jumlah'],
        'resi' => 'order-id-'.$resi, // Update 'resi' with generated random string
        'santri_id' => $data['santri_id']
    );

    // Required
    $transaction_details = array(
        'order_id' => 'order-id-'.$resi,
        'gross_amount' => $tagihan['jumlah'], // no decimal allowed for credit card
    );

    // Optional
    $item_details = array(
        array(
            'id' => 'order-id-'.$resi,
            'price' => $tagihan['jumlah'],
            'quantity' => 1,
            'name' => "Payment for " . $tagihan['bulan']
        )
    );

    // Optional
    $billing_address = array(
        'first_name'    => $data['nama_santri'],
        'last_name'     => $data['nama_santri'],
        'address'       => $data['asrama'],
        'city'          => "Jakarta", // Modify as necessary
        'postal_code'   => "16602", // Modify as necessary
        'phone'         => $data['no_hp'],
        'country_code'  => 'IDN'
    );

    // Optional
    $shipping_address = $billing_address; // Assuming billing and shipping addresses are the same

    // Optional
    $customer_details = array(
        'first_name'    => $data['nama_santri'],
        'last_name'     => $data['nama_santri'],
        'email'         => "santri@example.com", // Modify as necessary
        'phone'         => $data['no_hp'],
        'billing_address'  => $billing_address,
        'shipping_address' => $shipping_address
    );

    // Fill SNAP API parameter
    $params = array(
        'transaction_details' => $transaction_details,
        'customer_details' => $customer_details,
        'item_details' => $item_details,
        'enabled_payments' => [
            "credit_card",
            "mandiri_clickpay",
            "cimb_clicks",
            "bca_klikbca",
            "bca_klikpay",
            "bri_epay",
            "echannel",
            "indosat_dompetku",
            "mandiri_ecash",
            "permata_va",
            "bca_va",
            "bni_va",
            "other_va",
            "gopay",
            "kioson",
            "indomaret",
            "alfamart",
            "danamon_online",
            "akulaku"
        ]
    );

    // Check if the transaction is already created
    $resi_parts = explode("|", $data['resi']);
    $transactionId = $resi_parts[0];
    $existingUrl = isset($resi_parts[1]) ? $resi_parts[1] : null;

    if ($transactionId) {
        $result = getTransactionStatus($transactionId);
        $data = json_decode($result, true);
        $status_code = $data['status_code'];
       
        if ($status_code == 404) {
            // Create a new transaction
            
              $fcm_sql = "SELECT fcm FROM santri WHERE id = ?";
            $stmt = $conn->prepare($fcm_sql);
            $stmt->bind_param('i', $data_id);
            $stmt->execute();
            $fcm_result = $stmt->get_result();
            $fcm_data = $fcm_result->fetch_assoc();

            if ($fcm_data) {
                $token = $fcm_data['fcm'];
                $title = 'Pembayaran';
                $body = 'Sedang Melakukan Pembayaran';
                sendNotificationRequest($token, $title, $body);
            }
            $paymentUrls = createTransaction($params);
            $response = json_decode($paymentUrls);
            $paymentUrl = $response->redirect_url;
            
            // Update 'resi' with both random string and payment URL
            $update_resi = 'order-id-' . $resi . '|' . $paymentUrl;

            $update_sql = "UPDATE daftar_tagihan SET resi = ? WHERE id = ?";
                    
            // Menyiapkan statement
            $stmt = $conn->prepare($update_sql);
            if (!$stmt) {
                die("Gagal menyiapkan statement: " . $conn->error);
            }
                    
            // Mengikat parameter dan menjalankan statement
            $stmt->bind_param('si', $update_resi, $tagihan_id);
            if ($stmt->execute()) {
                
                header('Location: ' . $paymentUrl);
            } else {
                echo "Gagal mengupdate data: " . $stmt->error;
            }
        } else if ($status_code == 200) {
            // Update status to "lunas"
            $update_sql = "
                UPDATE daftar_tagihan
                SET status = 'Lunas'
                WHERE id = ? AND santri_id = ?;
            ";

            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param('ii', $tagihan_id, $data_id);
            $update_result = $stmt->execute();

            if (!$update_result) {
                die('Error updating status to lunas: ' . $stmt->error);
            }
            
             $fcm_sql = "SELECT fcm FROM santri WHERE id = ?";
            $stmt = $conn->prepare($fcm_sql);
            $stmt->bind_param('i', $data_id);
            $stmt->execute();
            $fcm_result = $stmt->get_result();
            $fcm_data = $fcm_result->fetch_assoc();

            if ($fcm_data) {
                $token = $fcm_data['fcm'];
                $title = 'Pembayaran';
                $body = 'Sudah lunas';
                sendNotificationRequest($token, $title, $body);
            }
            
            include 'index.php';
        } else {
            // Redirect to the existing URL
            header('Location: ' . $existingUrl);
            exit;
        }
    } else {
        echo "No data found or transaction ID missing.";
    }
} else {
    echo "No data found.";
}

$conn->close();

function getTransactionStatus($transactionId) {
    $url = "https://api.midtrans.com/v2/" . $transactionId . "/status";
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Basic TWlkLXNlcnZlci1VenFnSEpDSUdLRlZHbUxpZGs2X0pvamI6'
    ));

    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);

    return $result;
}

function createTransaction($params) {
    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, 'https://app.midtrans.com/snap/v1/transactions');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
    
    $headers = array();
    $headers[] = 'Content-Type: application/json';
    $headers[] = 'Accept: application/json';
    $headers[] = 'Authorization: Basic ' . base64_encode('Mid-server-UzqgHJCIGKFVGmLidk6_Jojb' . ':');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);
    return $result;
}

function sendNotificationRequest($token, $title, $body) {
    // Initialize cURL session
    $ch = curl_init();

    // Hardcoded service account URL
    $serviceAccountUrl = 'https://yusril.sikapngalah.com/api/serviceAccountKey.json';

    // Prepare the URL with query parameters
    $url = sprintf(
        'http://147.139.201.32:37000/sendNotification?token=%s&title=%s&body=%s&serviceAccountUrl=%s',
        urlencode($token),
        urlencode($title),
        urlencode($body),
        urlencode($serviceAccountUrl)
    );

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

    // Set HTTP headers
    $headers = array();
    $headers[] = 'Accept: */*';
    $headers[] = 'User-Agent: Thunder Client (https://www.thunderclient.com)';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Execute the cURL request
    $result = curl_exec($ch);

    // Check for cURL errors
    if (curl_errno($ch)) {
        $error = 'Error:' . curl_error($ch);
        curl_close($ch);
        return $error;
    }

    // Close cURL session
    curl_close($ch);

    // Return the result
    return $result;
}
?>
