<?php
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://app.midtrans.com/snap/v1/transactions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{"transaction_details":{"order_id":"order-id-47a89d83c9","gross_amount":300000},"customer_details":{"first_name":null,"last_name":null,"email":"santri@example.com","phone":"6281554850403","billing_address":{"first_name":null,"last_name":null,"address":"N.Kantor","city":"Jakarta","postal_code":"16602","phone":"6281554850403","country_code":"IDN"},"shipping_address":{"first_name":null,"last_name":null,"address":"N.Kantor","city":"Jakarta","postal_code":"16602","phone":"6281554850403","country_code":"IDN"}},"item_details":[{"id":"order-id-47a89d83c9","price":300000,"quantity":1,"name":"Payment for Agustus"}],"enabled_payments":["credit_card","mandiri_clickpay","cimb_clicks","bca_klikbca","bca_klikpay","bri_epay","echannel","indosat_dompetku","mandiri_ecash","permata_va","bca_va","bni_va","other_va","gopay","kioson","indomaret","alfamart","danamon_online","akulaku"]}");

$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Accept: application/json';
$headers[] = 'Authorization: Basic ' . base64_encode('Mid-server-UzqgHJCIGKFVGmLidk6_Jojb' . ':');
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
print_r($result);
