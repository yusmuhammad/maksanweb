<?php
// require '../../../db.php';

// // Ambil parameter dari URL
// $order_id = $_GET['order_id'];
// $status_code = $_GET['status_code'];
// $transaction_status = $_GET['transaction_status'];



// $status_message = '';
// $header_color = '';

// if ($status_code == 200) {
//     if ($transaction_status == 'settlement') {
//         // Update status menjadi 'Lunas'
//         $update_sql = "
//             SELECT * FROM `daftar_tagihan` WHERE `status` LIKE 'belum lunas' AND `resi` LIKE '%".$order_id."%'';
//         ";

//         $stmt = $conn->prepare($update_sql);
//         $stmt->bind_param('ii', $tagihan_id, $data_id);
//         $update_result = $stmt->execute();

//         if ($update_result) {
//             $status_message = 'Tagihan telah lunas. Terima kasih atas pembayaran Anda!';
//             $header_color = 'green';
//         } else {
//             $status_message = 'Gagal memperbarui status: ' . $stmt->error;
//             $header_color = 'red';
//         }
//     } else{
//         // Update status menjadi 'Dibatalkan'
//         $update_sql = "
//             UPDATE daftar_tagihan
//             SET status = 'Belum Lunas'
//             WHERE id = ? AND santri_id = ?;
//         ";

//         $stmt = $conn->prepare($update_sql);
//         $stmt->bind_param('ii', $tagihan_id, $data_id);
//         $update_result = $stmt->execute();

//         if ($update_result) {
//             $status_message = 'Pembayaran dibatalkan.';
//             $header_color = 'red';
//         } else {
//             $status_message = 'Gagal memperbarui status: ' . $stmt->error;
//             $header_color = 'red';
//         }
//     } else {
//         $status_message = 'Status transaksi tidak dikenali.';
//         $header_color = 'red';
//     }
// } else {
//     $status_message = 'Kode status tidak sesuai.';
//     $header_color = 'red';
// }

// $conn->close();
            $status_message = 'Pembayaran dibatalkan.';
            $header_color = 'red';
 ?>

<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Status Pembayaran</title>
    <link href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        .paid-animation {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            animation: fadeIn 2s;
        }
        .status-header {
            color: <?php echo $header_color; ?>;
        }
        @keyframes fadeIn {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <div class='paid-animation'>
        <div class='card text-center'>
            <div class='card-header status-header'>
                Status Pembayaran
            </div>
            <div class='card-body'>
                <h5 class='card-title'>Status Pembayaran</h5>
                <h1 class='status-header' style='font-weight: bold;'><?php echo ($header_color == 'green') ? 'Sudah Lunas' : 'Dibatalkan'; ?></h1>
                <p class='card-text'><?php echo $status_message; ?></p>
            </div>
            <div class='card-footer text-muted'>
                &copy; 2024 - Ponpes Ngalah
            </div>
        </div>
    </div>
    <script src='https://code.jquery.com/jquery-3.5.1.slim.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js'></script>
    <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'></script>
</body>
</html>
