<?php
// db.php
$servername = "localhost";
$username = "sika2255_yusril";
$password = "(ZH50g-3Inv)";
$dbname = "sika2255_yusril";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
