<?php
include 'db.php';
include 'templates/header.php';

$asrama = $_GET['asrama'];
$sql = "SELECT * FROM `santri` WHERE `asrama` LIKE '$asrama'";
$result = $conn->query($sql);

function hitungKuponSisa($conn, $santri_id)
{
    $total_kupon = 60;
    $bulanSekarang = date('m');
    $sql = "SELECT * FROM `history_pengambilan` WHERE MONTH(`tanggal`) = $bulanSekarang AND `santri_id` = $santri_id";
    $result = $conn->query($sql);

    $total_pengambilan = 0;

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if (!empty($row['jam_1']) && $row['jam_1'] !== "belum diambil") {
                $total_pengambilan++;
            }
            if (!empty($row['jam_2']) && $row['jam_2'] !== "belum diambil") {
                $total_pengambilan++;
            }
        }
    }

    $sisa_kupon = $total_kupon - $total_pengambilan;

    return $sisa_kupon;
}
?>

<div class="container">
    <h2 class="mt-5">Daftar Santri</h2>
    <?php
    $sqla = "SELECT DISTINCT asrama FROM santri";
    $resulta = $conn->query($sqla);

    if ($resulta === false) {
        die("Gagal menjalankan query: " . $conn->error);
    }

    if ($resulta->num_rows > 0) {
        echo "<div style='margin-bottom: 20px;'>";
        while ($rowa = $resulta->fetch_assoc()) {
            $asramaa = $rowa['asrama'];
            echo "<a href='index.php?asrama=" . urlencode($asramaa) . "' class='btn btn-primary btn-sm mb-2 mr-2 text-uppercase'>" . strtoupper($asramaa) . "</a>";
        }
        echo "</div>";
    } else {
        echo "<p>Tidak ada data santri.</p>";
    }
    ?>

    <a href="add_santri.php" class="btn btn-success mb-3">Tambah Santri Baru</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th style="width: 5%; text-align: center">No</th>
                <th style="width: 20%; text-align: center">Nama Santri</th>
                <th style="width: 10%; text-align: center">Asrama</th>
                <th style="width: 10%; text-align: center">No HP</th>
                <th style="width: 10%; text-align: center">Kuota Bulan ini</th>
                <th style="width: 20%; text-align: center">Aksi</th>
                <th style="width: 20%; text-align: center">Cetak Kartu</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                $n = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td style='text-align: center'>" . $n . "</td>
                            <td>" . $row["nama_santri"] . "</td>
                            <td style='text-align: center'>" . $row["asrama"] . "</td>
                            <td style='text-align: center'>" . $row["no_hp"] . "</td>
                            <td style='text-align: center'>" . hitungKuponSisa($conn, $row["id"]) . "</td>
                            <td style='vertical-align: middle; text-align: center'>
                                <a href='edit_santri.php?id=" . $row["id"] . "' class='btn btn-success btn-sm'>Edit</a>
                                <button class='btn btn-warning btn-sm' onclick='sendNotification(" . $row["id"] . ")'>Notif</button>
                                <a href='history-user.php?id=" . $row["id"] . "' class='btn btn-primary btn-sm'>Riwayat</a>
                            </td>
                            <td style='text-align: center'>
                                <a href='cetak_kartu.php?id=" . $row["id"] . "' class='btn btn-primary btn-sm'>Cetak Kartu</a>
                            </td>
                          </tr>";
                    $n++;
                }
            } else {
                echo "<tr><td colspan='8'>Pilih Kamar Dahulu</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php
include 'templates/footer.php';
?>

<script>
    function sendNotification(id) {
        var xhr = new XMLHttpRequest();
        var url = 'notif.php?id=' + id;
        
        xhr.open('GET', url, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.status === 'success') {
                    alert('Notification sent successfully');
                    window.location.reload(); // Reload the page
                } else {
                    alert('Failed to send notification: ' + response.message);
                }
            }
        };
        xhr.send();
    }
</script>
