<?php
include 'db.php';
include 'templates/header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_santri = $_POST["nama_santri"];
    $asrama = $_POST["asrama"];
    $nama_walisantri = $_POST["nama_walisantri"];
    $jatah_ambil_makan_bulan_ini = $_POST["jatah_ambil_makan_bulan_ini"];
    $no_hp = $_POST["no_hp"];
    $password = $_POST["password"];

    // Hash the password before storing it


    $sql = "INSERT INTO santri (nama_santri, asrama, nama_walisantri, jatah_ambil_makan_bulan_ini, no_hp, password) 
            VALUES ('$nama_santri', '$asrama', '$nama_walisantri', '$jatah_ambil_makan_bulan_ini', '$no_hp', '$password')";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<div class="container">
    <h2 class="mt-5">Tambah Santri Baru</h2>
    <form method="post" action="add_santri.php">
        <div class="form-group">
            <label for="nama_santri">Nama Santri:</label>
            <input type="text" class="form-control" id="nama_santri" name="nama_santri" placeholder="Nama Santri" required>
        </div>
        <div class="form-group">
            <label for="asrama">Asrama:</label>
            <input type="text" class="form-control" id="asrama" name="asrama" placeholder="Asrama" required>
        </div>
        <div class="form-group">
            <label for="nama_walisantri">Nama Walisantri:</label>
            <input type="text" class="form-control" id="nama_walisantri" name="nama_walisantri" placeholder="Nama Walisantri" required>
        </div>
        <div class="form-group">
            <label for="jatah_ambil_makan_bulan_ini">Jatah Ambil Makan Bulan Ini:</label>
            <input type="number" class="form-control" id="jatah_ambil_makan_bulan_ini" name="jatah_ambil_makan_bulan_ini" placeholder="Jatah Ambil Makan" required>
        </div>
        <div class="form-group">
            <label for="no_hp">No HP:</label>
            <input type="number" class="form-control" id="no_hp" name="no_hp" placeholder="628xxxxxxx" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="text" class="form-control" id="password" name="password" placeholder="Password" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<?php
include 'templates/footer.php';
?>