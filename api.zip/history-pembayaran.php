<?php
include 'templates/header.php';
include 'db.php';
?>
<div class="container">
    <?php

    // Query SQL untuk mengambil semua data santri
    $sqla = "SELECT DISTINCT asrama FROM santri"; // Menggunakan DISTINCT untuk mendapatkan nilai asrama yang unik
    $resulta = $conn->query($sqla);

    if ($resulta === false) {
        die("Gagal menjalankan query: " . $conn->error);
    }

    // Memproses hasil query jika data ditemukan
    if ($resulta->num_rows > 0) {
        echo "<div style='margin-bottom: 20px;margin-top: 20px;'>";

        while ($rowa = $resulta->fetch_assoc()) {
            $asramaa = $rowa['asrama'];
            echo "<a href='history-pembayaran.php?asrama=" . urlencode($asramaa) . "' style='margin-right: 10px; margin-bottom: 10px; padding: 8px 12px; background-color: #007bff; color: #fff; text-decoration: none; border-radius: 5px;'>" . strtoupper($asramaa) . "</a>";
        }

        echo "</div>";
    } else {
        echo "<p>Tidak ada data santri.</p>";
    }
    // Default query SQL tanpa filter
    $sql = "SELECT dt.id, dt.bulan, dt.jumlah, dt.status, dt.resi, dt.santri_id, s.nama_santri, s.asrama, s.nama_walisantri, s.no_hp, dt.tanggal
        FROM daftar_tagihan dt
        INNER JOIN santri s ON dt.santri_id = s.id";

    // Jika parameter 'asrama' ada dalam GET, tambahkan kondisi WHERE untuk filter asrama N1
    if (isset($_GET['asrama'])) {
        $sql .= " WHERE asrama = '" . $_GET['asrama'] . "'";
    }

    $result = $conn->query($sql);

    if ($result === false) {
        die("Gagal menjalankan query: " . $conn->error);
    }

    // Menampilkan data jika hasil query tidak kosong
    if ($result->num_rows > 0) {
        echo "<h2 class='mb-3'>Tabel Laporan Tagihan dengan Informasi Santri</h2>";

        echo "<table class='table table-bordered'>";
        echo "<thead class='thead-dark'>";
        echo "<tr>
        <th>No</th>
        <th>Bulan</th>
        <th>Jumlah</th>
        <th>Status</th>
        <th>Nama Santri</th>
        <th>Asrama</th>
        <th>Nama Wali Santri</th>
        <th>No HP</th>
        <th>Tanggal</th>
        </tr>";
        echo "</thead><tbody>";

        // Loop untuk menampilkan setiap baris data
        $n = 1;
        while ($row = $result->fetch_assoc()) {
            $resi_parts = explode("|", $row['resi']);
            echo "<tr>";
            echo "<td>" . $n . "</td>";
            echo "<td>" . $row['bulan'] . "</td>";
            echo "<td>" . number_format($row['jumlah'], 0, ',', '.') . "</td>"; // Format jumlah menjadi format uang
            echo "<td>" . $row['status'] . "</td>"; // Menampilkan status dengan kata "Lunas" atau "Belum Lunas"
            echo "<td>" . $row['nama_santri'] . "</td>";
            echo "<td>" . $row['asrama'] . "</td>";
            echo "<td>" . $row['nama_walisantri'] . "</td>";
            echo "<td>" . $row['no_hp'] . "</td>";
            echo "<td>" . $row['tanggal'] . "</td>"; // Menggunakan 'tanggal' dari hasil query untuk kolom Tanggal
            echo "</tr>";
            $n++;
        }

        echo "</tbody></table>";
    } else {
        echo "<p>Tidak ada data untuk ditampilkan.</p>";
    }

    // Menutup koneksi
    $conn->close();
    ?>
</div>
<?php
include 'templates/footer.php';
?>