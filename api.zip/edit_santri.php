<?php
include 'db.php';
include 'templates/header.php';

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $sql = "SELECT * FROM santri WHERE id=$id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Santri tidak ditemukan";
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $nama_santri = $_POST["nama_santri"];
    $asrama = $_POST["asrama"];
    $nama_walisantri = $_POST["nama_walisantri"];
    $jatah_ambil_makan_bulan_ini = $_POST["jatah_ambil_makan_bulan_ini"];
    $status_pembayaran = $_POST["status_pembayaran"];
    $no_hp = $_POST["no_hp"];
    $passwords = $_POST["password"];
    $sql = "UPDATE santri SET 
                nama_santri='$nama_santri', 
                asrama='$asrama', 
                nama_walisantri='$nama_walisantri', 
                jatah_ambil_makan_bulan_ini='$jatah_ambil_makan_bulan_ini', 
                no_hp='$no_hp',
                password='$passwords'
                WHERE id=$id";


    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<div class="container">
    <h2 class="mt-5">Edit Data Santri</h2>
    <div class="text-right mb-3">
        <a href='delete_santri.php?id=<?php echo $row["id"]; ?>' class='btn btn-danger' onclick='return confirm("Apakah Anda yakin?")'>Hapus</a>
    </div>
    <form method="post" action="edit_santri.php">
        <input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
        <div class="form-group">
            <label for="nama_santri">Nama Santri:</label>
            <input type="text" class="form-control" id="nama_santri" name="nama_santri" placeholder="Nama Santri" value="<?php echo $row["nama_santri"]; ?>" required>
        </div>
        <div class="form-group">
            <label for="asrama">Asrama:</label>
            <input type="text" class="form-control" id="asrama" name="asrama" placeholder="Asrama" value="<?php echo $row["asrama"]; ?>" required>
        </div>
        <div class="form-group">
            <label for="nama_walisantri">Nama Walisantri:</label>
            <input type="text" class="form-control" id="nama_walisantri" name="nama_walisantri" placeholder="Nama Walisantri" value="<?php echo $row["nama_walisantri"]; ?>" required>
        </div>
        <div class="form-group">
            <label for="jatah_ambil_makan_bulan_ini">Jatah Ambil Makan Bulan Ini:</label>
            <input type="number" class="form-control" id="jatah_ambil_makan_bulan_ini" name="jatah_ambil_makan_bulan_ini" placeholder="Jatah Ambil Makan" value="<?php echo $row["jatah_ambil_makan_bulan_ini"]; ?>" required>
        </div>
        <div class="form-group">
            <label for="no_hp">No HP:</label>
            <input type="number" class="form-control" id="no_hp" name="no_hp" placeholder="628xxxxxxx" value="<?php echo $row["no_hp"]; ?>" required>
        </div>
        <div class="form-group">
            <label for="password">Password Baru:</label>
            <input type="text" class="form-control" id="password" name="password" value="<?php echo $row["password"]; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>

<?php
include 'templates/footer.php';
?>