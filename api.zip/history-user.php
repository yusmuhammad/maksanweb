<?php
include 'db.php'; // Menghubungkan ke file koneksi database
include 'templates/header.php';
$id = $_GET['id'];

// Query SQL untuk mengambil data daftar tagihan berdasarkan santri_id
$sql = "SELECT dt.id, dt.bulan, dt.jumlah, dt.status, dt.resi, dt.tanggal, s.nama_santri, s.asrama, s.nama_walisantri, s.no_hp
        FROM daftar_tagihan dt
        INNER JOIN santri s ON dt.santri_id = s.id
        WHERE s.id = $id
        ORDER BY dt.id DESC";

$result = $conn->query($sql);

if ($result === false) {
    die("Gagal menjalankan query: " . $conn->error);
}

// Query SQL untuk mengambil data santri berdasarkan id
$sqlSantri = "SELECT * FROM santri WHERE id = $id";
$resultSantri = $conn->query($sqlSantri);

if ($resultSantri->num_rows > 0) {
    $santri = $resultSantri->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Santri dan Tagihan</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
    <script>
        function updateStatus(id) {
            var xhr = new XMLHttpRequest();
            var url = 'bayar-manual.php?id=' + id;
            
            xhr.open('GET', url, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        alert('Record updated successfully');
                        window.location.reload(); // Reload the page
                    } else {
                        alert('Failed to update record: ' + response.message);
                    }
                }
            };
            xhr.send();
        }
    </script>
</head>

<body>
    <div class="container">
        <h2>Data Santri: <?php echo $santri['nama_santri']; ?></h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Nama Santri</th>
                <th>Asrama</th>
                <th>Nama Wali Santri</th>
                <th>No HP</th>
            </tr>
            <tr>
                <td><?php echo $santri['id']; ?></td>
                <td><?php echo $santri['nama_santri']; ?></td>
                <td><?php echo $santri['asrama']; ?></td>
                <td><?php echo $santri['nama_walisantri']; ?></td>
                <td><?php echo $santri['no_hp']; ?></td>
            </tr>
        </table>

        <h2>Daftar Tagihan</h2>
        <?php if ($result->num_rows > 0) : ?>
            <table>
                <tr>
                    <th>No</th>
                    <th>Bulan</th>
                    <th>Jumlah</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
                <?php $n = 1;
                while ($row = $result->fetch_assoc()) : ?>
                    <tr>
                        <td><?php echo $n++; ?></td>
                        <td><?php echo $row['bulan']; ?></td>
                        <td><?php echo number_format($row['jumlah'], 0, ',', '.'); ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['tanggal']; ?></td>
                        <td>
                            <?php if ($row['status'] === 'Lunas') : ?>
                                <button type="button" class="btn btn-light" disabled>Bayar Manual</button>
                            <?php else : ?>
                                <button type="button" class="btn btn-success" onclick="updateStatus(<?php echo $row['id']; ?>)">Bayar Manual</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else : ?>
            <p>Tidak ada data tagihan untuk santri ini.</p>
        <?php endif; ?>
    </div>
</body>

</html>

<?php
} else {
    echo "<p>Santri dengan ID $id tidak ditemukan.</p>";
}

// Menutup koneksi
$conn->close();

include 'templates/footer.php';
?>
